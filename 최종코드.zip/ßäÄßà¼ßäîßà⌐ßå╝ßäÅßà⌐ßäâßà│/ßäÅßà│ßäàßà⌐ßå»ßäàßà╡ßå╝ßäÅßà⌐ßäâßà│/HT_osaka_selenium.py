import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from time import sleep
from datetime import datetime, timedelta

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable_dev-shm-usage')

user_agent = {
    "User-Agent": 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
}

chrome_options.add_argument(f"user-agent={user_agent}")
# Mac에서 brew로 설치한 chromedriver의 경로
webdriver_path = '/usr/local/bin/chromedriver'

# 크롬 브라우저 실행
service = Service(executable_path='/usr/local/bin/chromedriver')
driver = webdriver.Chrome(service=service)

# Start date and end date settings (from August 1, 2023 to August 2, 2023)
start_date = datetime(2023, 8, 1)
end_date = datetime(2023, 8, 31)

# Create an empty list to store hotel information
hotel_data = []

for i in range((end_date - start_date).days + 1):
    date = start_date + timedelta(days=i)
    date_str = date.strftime("%Y-%m-%d")
    end_date_str = (date + timedelta(days=1)).strftime("%Y-%m-%d")  # Check-out date
    
    # Loop through pages 1 to 5 for each date
    for page in range(1, 6):
        url = f'https://hotels.naver.com/list?placeFileName=place%3AOsaka&adultCnt=1&checkIn={date_str}&checkOut={end_date_str}&includeTax=false&sortField=popularityKR&sortDirection=descending&pageIndex={page}'
        driver.get(url)
        sleep(15)

        try:
            # Get hotel and price information
            hotel_elements = driver.find_elements(By.CSS_SELECTOR, '.Detail_InfoArea__uZ4qT')
            price_elements = driver.find_elements(By.CSS_SELECTOR, '.Price_Price__7vul8')
            thumbnail_elements = driver.find_elements(By.CSS_SELECTOR, '.Detail_Thumbnail__NYaJI img')
            for i in range(len(hotel_elements)):
                element = hotel_elements[i]
                price_element = price_elements[i]
                thumbnail_element = thumbnail_elements[i]
                hotel_name = element.find_element(By.CSS_SELECTOR, 'h4.Detail_title__40_dz').text
                hotel_location = element.find_element(By.CSS_SELECTOR, 'i.Detail_location__u3_N6').text
                hotel_score = element.find_element(By.CSS_SELECTOR, 'i.Detail_score__UxnqZ').text
                try:
                    hotel_grade = element.find_element(By.CSS_SELECTOR, 'i.Detail_grade__y5BmJ').text
                except:
                    hotel_grade = None
                hotel_price = price_element.find_element(By.CSS_SELECTOR, 'em.Price_show_price__iQpms').text
                thumbnail_url = thumbnail_element.get_attribute('src')

                # Create a dictionary to store hotel information
                hotel_info = {
                    'Check-in Date': date_str,
                    'Check-out Date': end_date_str,
                    'Hotel Name': hotel_name,
                    'Location': hotel_location,
                    'Rating': hotel_score,
                    'Grade': hotel_grade,
                    'Price': hotel_price,
                    'Thumbnail URL': thumbnail_url,
                }
                hotel_data.append(hotel_info)
        except Exception as e:
            print("Error occurred:", e)

driver.quit()

# Convert hotel information and price data to a DataFrame
hotel_df = pd.DataFrame(hotel_data)
# Save the DataFrame to a CSV file
hotel_df.to_csv('hotel_data_with_price_and_thumbnail.csv', index=False)
