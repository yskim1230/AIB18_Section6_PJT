import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from time import sleep
from datetime import datetime, timedelta

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable_dev-shm-usage')
user_agent = {
    "User-Agent" : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
}

chrome_options.add_argument(f"user-agent={user_agent}")
# Mac에서 brew로 설치한 chromedriver의 경로
webdriver_path = '/usr/local/bin/chromedriver'

# 크롬 브라우저 실행
service = Service(executable_path='/usr/local/bin/chromedriver')
driver = webdriver.Chrome(service=service)

# 시작 날짜와 종료 날짜 설정 (2023년 8월 1일부터 31일까지 조회)
start_date = datetime(2023, 9, 1)
end_date = datetime(2023, 9, 8)

# 데이터프레임을 저장할 빈 리스트 생성
flight_data = []

# 날짜를 하루씩 증가시키면서 크롤링 진행
current_date = start_date
while current_date <= end_date:
    # 날짜 정보를 URL에 반영하여 해당 날짜의 URL 구성
    # URL 맨뒤 fareType 에 따라 좌석등급이 나눠짐
    # 'fareType=Y' -> '일반석'
    # 'fareType=P' -> '프리미엄일반석'
    # 'fareType=C' -> '비즈니스'
    # 'fareType=F' -> '일등석'


    date_str = current_date.strftime("%Y%m%d")
    url = f'https://m-flight.naver.com/flights/international/ICN-OSA-{date_str}?adult=1&isDirect=true&fareType=C'
    
    driver.get(url)
    sleep(15)

    try:
        # 항공사 정보 가져오기
        airline_elements = driver.find_elements(By.CSS_SELECTOR, '.airline')
        route_elements = driver.find_elements(By.CSS_SELECTOR, 'div.route_Route__2UInh')
        price_elements = driver.find_elements(By.CSS_SELECTOR, 'div.item_price__1TxJh')

        print("날짜:", date_str)
        print("항공사 정보 개수:", len(airline_elements))
        print("경로 정보 개수:", len(route_elements))
        print("가격 정보 개수:", len(price_elements))

        if len(airline_elements) == len(route_elements) == len(price_elements):
            for idx in range(len(route_elements)):
                route_element = route_elements[idx]
                price_element = price_elements[idx]

                # 출발 정보 가져오기
                departure_element = route_element.find_elements(By.CSS_SELECTOR, 'span.route_airport__3VT7M')[0]
                departure_time = departure_element.find_element(By.CSS_SELECTOR, 'b.route_time__-2Z1T').text.strip()
                departure_location = departure_element.find_element(By.CSS_SELECTOR, 'i.route_code__3WUFO').text.strip()

                # 도착 정보 가져오기
                arrival_element = route_element.find_elements(By.CSS_SELECTOR, 'span.route_airport__3VT7M')[1]
                arrival_time = arrival_element.find_element(By.CSS_SELECTOR, 'b.route_time__-2Z1T').text.strip()
                arrival_location = arrival_element.find_element(By.CSS_SELECTOR, 'i.route_code__3WUFO').text.strip()

                # 추가 정보 (직항 여부, 비행 시간) 가져오기
                additional_info_element = route_element.find_element(By.CSS_SELECTOR, 'i.route_info__1RhUH')
                additional_info = additional_info_element.text.strip()

                # 항공사명 가져오기
                airline_name = airline_elements[idx].find_element(By.CSS_SELECTOR, 'b.name').text.strip()

                # 항공권 가격 가져오기
                try:
                    ticket_price_element = price_element.find_element(By.CSS_SELECTOR, 'b.item_promoted__2eSDk i.item_num__3R0Vz')
                except:
                    ticket_price_element = price_element.find_element(By.CSS_SELECTOR, 'b.item_usual__dZqAN i.item_num__3R0Vz')

                ticket_price = ticket_price_element.text.strip()

                # 좌석정보 추가
                fare_type = '알 수 없음'
                if 'fareType=Y' in url:
                    fare_type = '일반석'
                elif 'fareType=P' in url:
                    fare_type = '프리미엄일반석'
                elif 'fareType=C' in url:
                    fare_type = '비즈니스'
                elif 'fareType=F' in url:
                    fare_type = '일등석'

                # Create a dictionary to store airline information
                airline_info = {
                    'date': date_str,
                    'airline_name': airline_name,
                    'departure_time': departure_time,
                    'departure_location': departure_location,
                    'arrival_time': arrival_time,
                    'arrival_location': arrival_location,
                    'additional_info': additional_info,
                    'ticket_price': ticket_price,
                    'seat_info': fare_type,
                    # Add other relevant information if needed
                }
                flight_data.append(airline_info)
        else:
            print("오류 발생: 항공사 정보, 경로 정보, 가격 정보의 개수가 일치하지 않습니다.")

    except Exception as e:
        print("오류 발생:", e)

    # 다음 날짜로 이동
    current_date += timedelta(days=1)

# 브라우저 닫기
driver.quit()

# 데이터프레임으로 변환
df = pd.DataFrame(flight_data)

# CSV 파일로 저장
csv_file_path = 'flight_data_osa(9월비즈니스).csv'
df.to_csv(csv_file_path, index=False)

print("데이터가 CSV 파일로 저장되었습니다:", csv_file_path)
