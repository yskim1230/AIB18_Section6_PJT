CREATE DEFINER=`admin`@`%` PROCEDURE `aibsection6pjt`.`Gettrip`(
    IN date1_str VARCHAR(8),
    IN date2_str VARCHAR(8),
    IN min_price_air INT,
    IN max_price_air INT
)
BEGIN
    SELECT 
	date_osa 				,
	airline_name_osa 		,
	departure_time_osa 		,
	departure_location_osa	,
	arrival_time_osa 		,
	arrival_location_osa 	,
	additional_info_osa 	,
	ticket_price_osa 		,
	seat_info_osa 			,
	date_icn 				,
	airline_name_icn 		,
	departure_time_icn 		,
	departure_location_icn 	,
	arrival_time_icn 		,
	arrival_location_icn 	,
	additional_info_icn 	,
	ticket_price_icn 		,
	seat_info_icn 			,
	ticket_total  			
    FROM TFERoundSch ts 
    WHERE date_osa = date1_str 
    AND date_icn = date2_str
    AND ticket_total BETWEEN min_price_air AND max_price_air
    ORDER BY ticket_total;
END